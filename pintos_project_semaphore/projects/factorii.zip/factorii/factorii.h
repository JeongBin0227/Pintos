#ifndef __PROJECTS_FACTORII_FACTORII_H__
#define __PROJECTS_FACTORII_FACTORII_H__

void run_factorii(char **argv);

#endif 
