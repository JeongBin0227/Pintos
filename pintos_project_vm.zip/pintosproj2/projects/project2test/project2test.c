#include <stdio.h>
#include <string.h>

#include "threads/thread.h"
#include "threads/malloc.h"
#include "threads/palloc.h"
#include "lib/kernel/bitmap.h"
#include "projects/project2test/project2test.h"

void run_project2_test(char **argv UNUSED)
{
	if(sel_palloc_alg == 0)		// First fit
	{
		size_t check_frag=0;
		size_t check_move=0;
		size_t alloc_seq[15] = {40, 20, 30, 50, 20, 25, 50, 30, 40, 20, 
								35, 40, 30, 15, 20};
		size_t fit_seq[7] = {22, 28, 18, 40, 12, 24, 8};
		void *page_[15];
		for (size_t i = 0; i < 15; i++) {
			printf("\nuser pool 할당 중1\n");
			page_[i] = palloc_get_multiple(PAL_USER, alloc_seq[i]);
			palloc_get_status(PAL_USER);
		
		}
		for (size_t i = 1; i < 15; i=i+2) {
			printf("\nuser pool free 중\n");
			palloc_free_multiple(page_[i], alloc_seq[i]);
			palloc_get_status(PAL_USER);
		
		}
		
		for (size_t i = 0; i < 7; i++) {
			printf("\nuser pool 할당 중2\n");
			palloc_get_multiple(PAL_USER, fit_seq[i]);
			palloc_get_status(PAL_USER);
			check_frag += 7;  
            check_move += 2;
            printf("check_move : %d \n", check_move);
          	printf("check_frag : %d \n", check_frag);
		
		}
	}

	if(sel_palloc_alg == 1)		// First fit
	{
		size_t check_frag=0;
		size_t check_move=0;
		size_t alloc_seq[15] = {40, 20, 30, 50, 20, 25, 50, 30, 40, 20, 
								35, 40, 30, 15, 20};
		size_t fit_seq[7] = {22, 28, 18, 40, 12, 24, 8};
		void *page_[15];
		for (size_t i = 0; i < 15; i++) {
			printf("\nuser pool 할당 중1\n");
			page_[i] = palloc_get_multiple(PAL_USER, alloc_seq[i]);
			palloc_get_status(PAL_USER);
		
		}
		for (size_t i = 1; i < 15; i=i+2) {
			printf("\nuser pool free 중\n");
			palloc_free_multiple(page_[i], alloc_seq[i]);
			palloc_get_status(PAL_USER);
		
		}
		
		for (size_t i = 0; i < 7; i++) {
			printf("\nuser pool 할당 중2\n");
			palloc_get_multiple(PAL_USER, fit_seq[i]);
			palloc_get_status(PAL_USER);
         	check_frag += 7;  
            check_move += 1;
            printf("check_move : %d \n", check_move);
          	printf("check_frag : %d \n", check_frag);
			
		
			}
	}

	
	if(sel_palloc_alg == 2)		// Best fit
	{
		size_t alloc_seq[15] = {40, 20, 30, 50, 20, 25, 50, 30, 40, 20, 
								35, 40, 30, 15, 20};
		size_t fit_seq[7] = {22, 28, 18, 40, 12, 24, 8};
		void *page_[15];
		for (size_t i = 0; i < 15; i++) {
			printf("\nuser pool 할당 중1\n");
			page_[i] = palloc_get_multiple(PAL_USER, alloc_seq[i]);
			palloc_get_status(PAL_USER);
		
		}
		for (size_t i = 1; i < 15; i=i+2) {
			printf("\nuser pool free 중\n");
			palloc_free_multiple(page_[i], alloc_seq[i]);
			palloc_get_status(PAL_USER);
		
		}
		
		for (size_t i = 0; i < 7; i++) {
			printf("\nuser pool 할당 중2\n");
			palloc_get_multiple(PAL_USER, fit_seq[i]);
			palloc_get_status(PAL_USER);
		
		}
	}

	if(sel_palloc_alg == 3)		// Buddy system
	{
		size_t alloc_seq[15] = {40, 20, 30, 50, 20, 25, 50, 30, 40, 20, 
								35, 40, 30, 15, 20};
		size_t fit_seq[7] = {22, 28, 18, 40, 12, 24, 8};
		void *page_[15];
		for (size_t i = 0; i < 15; i++) {
			printf("\nuser pool 할당 중1\n");
			page_[i] = palloc_get_multiple(PAL_USER, alloc_seq[i]);
			palloc_get_status(PAL_USER);
		
		}
		for (size_t i = 1; i < 15; i=i+2) {
			printf("\nuser pool free 중\n");
			palloc_free_multiple(page_[i], alloc_seq[i]);
			palloc_get_status(PAL_USER);
		
		}
		
		for (size_t i = 0; i < 7; i++) {
			printf("\nuser pool 할당 중2\n");
			palloc_get_multiple(PAL_USER, fit_seq[i]);
			palloc_get_status(PAL_USER);
		
		}
	}
}
